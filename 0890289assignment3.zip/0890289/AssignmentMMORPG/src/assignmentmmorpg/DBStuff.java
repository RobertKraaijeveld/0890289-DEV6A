/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentmmorpg;

import static assignmentmmorpg.CharacterManagementGUI.currentUser;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import static javax.xml.bind.DatatypeConverter.parseDate;

/**
 *
 * @author Robert
 */
public class DBStuff
{
public static class GetDBAverages
{
   
    public static void FillCharactersTable()
   {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Random random = new Random();
        
        Date d = new Date();
               
        Characters charEntity = new Characters();
        for(int i= 0; i < 1000; i++)
        {
            charEntity.setClass1(randomString());
            charEntity.setLevel(random.nextInt(100));
            charEntity.setName(randomString());
            charEntity.setRace(randomString());
            charEntity.setOwner(randomString());
            em.persist(charEntity); 
           
        }
         em.getTransaction().commit();
   }
    
    
   public static void FillUsersTable()
   {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Random random = new Random();
        
        Date d = new Date();
        
        Users userEntity = new Users();
        for(int i= 0; i < 1000; i++)
        {
            userEntity.setBalance(random.nextInt(100));
            userEntity.setBanned(false);
            userEntity.setCharacterSlots(random.nextInt(100));
            userEntity.setIban(randomString());
            userEntity.setLastName(randomString());
            userEntity.setFirstName(randomString());
            userEntity.setLastPayment(d);
            userEntity.setMonthsPayed(random.nextInt(100));
            userEntity.setPassword(randomString());
            userEntity.setUserName(randomString());
            em.persist(userEntity);            
            
        }
        em.getTransaction().commit();
     }
   
   private static String randomString()
   {
        int leftlimit = 97;
        int rightLimit = 122;
        int targetStringLength = 10;
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for(int i=0; i < targetStringLength; i++)
        {
            int randomLimitedInt = leftlimit + (int) (new Random().nextFloat() * (rightLimit - leftlimit));
            buffer.append((char) randomLimitedInt);
        }
        return buffer.toString();
   }
   
   public static void GetAverages()
   {
       EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
       EntityManager em = emf.createEntityManager();
       em.getTransaction().begin();
       long begintime = System.currentTimeMillis();
       Query selectUserNameQuery = em.createNativeQuery("SELECT last_payment FROM Users WHERE user_name = '"+ randomString() +"'");
       List<Long> queryTimes = new ArrayList<Long>();
       for(int i  = 0; i < 100; i++)
       {
            selectUserNameQuery.getResultList();
            Long endtime = System.currentTimeMillis();
            Long thistime = endtime - begintime;
            queryTimes.add(thistime);
       }
       
       Long sum = 0L;
       Long finalAverage = 0L;
       //calculate average
       for(Long l : queryTimes)
       {
           sum += l;
       }
       finalAverage = sum / 100;
       System.out.println("Final average time in ms: " + finalAverage);
   }
   
}
}

