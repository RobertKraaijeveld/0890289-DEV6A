/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentmmorpg;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
*
* @author Robert
*/

public class CharacterManagementGUI 
{
    //Global vars
    static String currentUser;
    String[] CharArray;  
    JLabel paymentLabel;
    JTextField nameText;
    JComboBox CharacterList;
    JComboBox RaceList;
    JButton confirmButton;
    JFrame frame;
    JTextField slotText;
    JButton addSlotsButton;
    JTextField addCashText;
    JTextField ibanText;
    JLabel slotsCounter;
    JButton addCashButton;
    JLabel connectedLabel;
    
    JButton onemonth;
    JButton twomonths;
    JButton threemonths;
    JButton oneyear;
    JLabel timeLeftLabel;
    int totalTimeAdded;
    
    public void initGUI()
    {
	frame = new JFrame("Character Management");
	frame.setSize(1000,1600);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	JPanel panel = new JPanel();
	frame.add(panel);
	placeComponents(panel);

	frame.setVisible(true);	
    }
    
    private void placeComponents(JPanel panel)
    {
        //TODO: Add character info and slots amounts, randomize new char level
        panel.setLayout(null);

        //create new character
        
        JLabel titleLabel = new JLabel("Create a new character!");
	titleLabel.setBounds(10, 2, 250, 80);
        panel.add(titleLabel);
        
        slotsCounter = new JLabel("Hoeveelheid lege slots: " + getAmountOfSlots());
	slotsCounter.setBounds(10, 1, 160, 25);
	panel.add(slotsCounter);
        
        JLabel nameLabel = new JLabel("Name");
	nameLabel.setBounds(10, 20, 80, 80);
        panel.add(nameLabel);
        
        nameText = new JTextField(20);
	nameText.setBounds(100, 50, 160, 25);
	panel.add(nameText);
        
        JLabel classLabel = new JLabel("Class");
	classLabel.setBounds(10, 100, 80, 25);
        panel.add(classLabel);
        
        String[] CharacterClass = {"Mage", "Warrior", "Bowman", "Cleric"};       
        CharacterList = new JComboBox(CharacterClass);
        CharacterList.setSelectedIndex(3);
        CharacterList.setBounds(100, 100, 80, 25);
        panel.add(CharacterList);
        
        JLabel raceLabel = new JLabel("Race");
	raceLabel.setBounds(10, 150, 80, 25);
        panel.add(raceLabel);
        
        String[] RaceClass = {"Human", "Orc", "Dwarf", "Student"};       
        RaceList = new JComboBox(RaceClass);
        RaceList.setSelectedIndex(3);
        RaceList.setBounds(100, 150, 80, 25);
        panel.add(RaceList);
        
	confirmButton = new JButton("Confirm");
	confirmButton.setBounds(10, 200, 80, 25);
	panel.add(confirmButton);
        confirmButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    CreateNewCharacter();
                }
                });
        
        JLabel MoneyLabel = new JLabel("You have " + getCurrentFunds() + "$ available.");
	MoneyLabel.setBounds(10, 250, 250, 80);
        panel.add(MoneyLabel);
        
        JLabel SlotsAddLabel = new JLabel("Add more slots: 1$ each");
	SlotsAddLabel.setBounds(10, 300, 250, 80);
        panel.add(SlotsAddLabel);
        
        slotText = new JTextField(20);
	slotText.setBounds(100, 300, 160, 25);
	panel.add(slotText);
        
        addSlotsButton = new JButton("Add slots");
	addSlotsButton.setBounds(10, 350, 80, 25);
	panel.add(addSlotsButton);
        addSlotsButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddSlots();
                }
                });
        
        //list of owned chars
        JComboBox CharList = new JComboBox(getCharList());
        CharList.setSelectedIndex(0);
        CharList.setBounds(10, 380, 80, 25);
        panel.add(CharList);
        CharList.addActionListener (new ActionListener () {
        public void actionPerformed(ActionEvent e) {
            getCharStats(CharList.getSelectedItem().toString());
          }
        });
                 
        
        JLabel MoneyAddLabel = new JLabel("Add money: Enter IBAN, amount");
	MoneyAddLabel.setBounds(10, 400, 250, 80);
        panel.add(MoneyAddLabel);
        
        paymentLabel = new JLabel("Last payment: " + getLastPayment());
	paymentLabel.setBounds(300, 440, 250, 80);
        panel.add(paymentLabel);
        
        addCashText = new JTextField(20);
	addCashText.setBounds(100, 440, 160, 25);
	panel.add(addCashText);
        
        ibanText = new JTextField(20);
	ibanText.setBounds(100, 480, 160, 25);
	panel.add(ibanText);
        
        addCashButton = new JButton("Confirm");
	addCashButton.setBounds(10, 500, 80, 25);
	panel.add(addCashButton);
        addCashButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddCash();
                }
                });
	
    
        JButton connectButton = new JButton("Connect to server!");
	connectButton.setBounds(10, 500, 80, 25);
	panel.add(connectButton);
        connectButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    connectToServer();
                }
                });
	
    
        JButton disconnectButton = new JButton("Disconnect from the server!");
	disconnectButton.setBounds(10, 530, 80, 25);
	panel.add(disconnectButton);
        disconnectButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    disconnectToServer();
                }
                });
        
        JLabel subLabel = new JLabel("Renovate subscription");
	subLabel.setBounds(300, 400, 250, 20);
        panel.add(subLabel);
        
        timeLeftLabel = new JLabel("Your subscription will run out in " + TimeLeft() + "days");
	subLabel.setBounds(300, 480, 250, 20);
        panel.add(subLabel);
        
        //subscription stuff
        onemonth = new JButton("1 month: 5$");
	onemonth.setBounds(300, 520, 80, 25);
	panel.add(onemonth);
        onemonth.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddOneMonth();
                }
                });
        
        //subscription stuff
        twomonths = new JButton("2 months: 10$");
	twomonths.setBounds(300, 560, 80, 25);
	panel.add(twomonths);
        twomonths.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddTwoMonths();
                }
                });
        
        //subscription stuff
        threemonths = new JButton("3 month: 15$");
	threemonths.setBounds(300, 600, 80, 25);
	panel.add(threemonths);
        threemonths.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddThreeMonths();
                }
                });
	 
        //subscription stuff
        oneyear = new JButton("1 year: 40$");
	oneyear.setBounds(300, 640, 80, 25);
	panel.add(oneyear);
        oneyear.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    AddOneYear();
                }
                });
        
        }
        //SUBSCRIPTION METHODS
        private void AddOneMonth()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                
            //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
            TypedQuery<Users> checkNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
            checkNameAvailabilityQuery.setParameter("userName", currentUser);
            List<Users> knownUsers = checkNameAvailabilityQuery.getResultList();

            for(Users u : knownUsers)
            {
                if(u.getBalance() >= 5)
                {
                   u.setBalance(u.getBalance() - 5);
                   if(u.getMonthsPayed() != null)
                   {
                        u.setMonthsPayed(u.getMonthsPayed() + 1);
                        totalTimeAdded++;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                   else
                   {
                        u.setMonthsPayed(1);
                        totalTimeAdded++;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                }
                else
                {
                    showMessageDialog(frame, "U heeft niet genoeg geld!");
                }
            }
        }
        
        private void AddTwoMonths()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                
            //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
            TypedQuery<Users> checkNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
            checkNameAvailabilityQuery.setParameter("userName", currentUser);
            List<Users> knownUsers = checkNameAvailabilityQuery.getResultList();

            for(Users u : knownUsers)
            {
                if(u.getBalance() >= 10)
                {
                    u.setBalance(u.getBalance() - 10);
                   if(u.getMonthsPayed() != null)
                   {
                        u.setMonthsPayed(u.getMonthsPayed() + 2);
                        totalTimeAdded += 2;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                   else
                   {
                        u.setMonthsPayed(2);
                        totalTimeAdded++;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                }
                else
                {
                    showMessageDialog(frame, "U heeft niet genoeg geld!");
                }
            }
        }
        
        private void AddThreeMonths()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                
            //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
            TypedQuery<Users> checkNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
            checkNameAvailabilityQuery.setParameter("userName", currentUser);
            List<Users> knownUsers = checkNameAvailabilityQuery.getResultList();

            for(Users u : knownUsers)
            {
                if(u.getBalance() >= 15)
                {
                   u.setBalance(u.getBalance() - 15);
                   if(u.getMonthsPayed() != null)
                   {
                        u.setMonthsPayed(u.getMonthsPayed() + 3);
                        totalTimeAdded += 3;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                   else
                   {
                        u.setMonthsPayed(3);
                        totalTimeAdded++;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                }
                else
                {
                    showMessageDialog(frame, "U heeft te weinig geld");
                }
            }
        }
        
        private void AddOneYear()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                
            //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
            TypedQuery<Users> checkNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
            checkNameAvailabilityQuery.setParameter("userName", currentUser);
            List<Users> knownUsers = checkNameAvailabilityQuery.getResultList();

            for(Users u : knownUsers)
            {
                if(u.getBalance() >= 40)
                {
                   u.setBalance(u.getBalance() - 10);
                   if(u.getMonthsPayed() != null)
                   {
                        u.setMonthsPayed(u.getMonthsPayed() + 2);
                        totalTimeAdded += 2;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                   else
                   {
                        u.setMonthsPayed(2);
                        totalTimeAdded++;
                        em.persist(u);
                        em.getTransaction().commit();
                        showMessageDialog(frame, "Abbonement vernieuwd!");
                   }
                }
                else
                {
                    showMessageDialog(frame, "U heeft te weinig geld");
                }
              }
            
        }
        
        private String TimeLeft()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                
            //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
            TypedQuery<Users> checkNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
            checkNameAvailabilityQuery.setParameter("userName", currentUser);
            List<Users> knownUsers = checkNameAvailabilityQuery.getResultList();

            for(Users u : knownUsers)
            {
                return "You have " + u.getMonthsPayed() + " months left!";
            }
            return "You have an unknown amount of days left";
        }
        
        //OTHER METHODS
    
        private void CreateNewCharacter()
        {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
            EntityManager em = emf.createEntityManager();
                //check fields: No need to check the comboboxes since they have default values
                if(!"".equals(nameText.getText()) )
                {
                    //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
                    TypedQuery<Characters> checkNameAvailabilityQuery = em.createNamedQuery("Characters.findByName", Characters.class);
                    checkNameAvailabilityQuery.setParameter("name", nameText.getText());
                    List<Characters> knownChars = checkNameAvailabilityQuery.getResultList();
                    boolean taken = false;
                    
                    for(Characters character : knownChars)
                    {
                        if(nameText.getText().equals(character.getName()))
                        {
                            showMessageDialog(frame, "Deze characternaam is al bezet!");
                            taken = true;
                        }
                    }
                    if(taken == false)
                    {
                        insertCharToDB();
                    }
                }
                else
                {
                    //fields incorrect
                    showMessageDialog(frame, "U heeft 1 of meerdere velden niet ingevuld.");
                }  
        }
        
    private void insertCharToDB()    
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        //decrease character slots by 1; if slots too low return error
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        for(Users currentUsers : usersList)
        {
            if(currentUsers.getCharacterSlots() > 0)
            {
                //decrement slots, then proceed
                currentUsers.setCharacterSlots(currentUsers.getCharacterSlots() - 1);
                showMessageDialog(frame, "Aantal slots = " + currentUsers.getCharacterSlots());
                Characters charactersEntity = new Characters();
                //create new persistence object and save character in
                charactersEntity.setName(nameText.getText());
                charactersEntity.setClass1(CharacterList.getSelectedItem().toString());
                charactersEntity.setRace(RaceList.getSelectedItem().toString());
                //add owner column
                charactersEntity.setOwner(currentUser);
                //randomize level and persist db
                Random rndm = new Random();
                charactersEntity.setLevel(rndm.nextInt(100));
                showMessageDialog(frame, "Gefeliciteerd, " + nameText.getText() + " is klaar voor de strijd!");
                em.persist(charactersEntity);
                em.getTransaction().commit();
            }
            else
            {
                //not enough slots
                showMessageDialog(frame, "U heeft niet genoeg vrije slots!");
            }  
        }
    }
    
    private String[] getCharList()    
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        //decrease character slots by 1; if slots too low return error
        TypedQuery<Characters> getCharListQuery = em.createNamedQuery("Characters.findByOwner", Characters.class);
        getCharListQuery.setParameter("owner", currentUser);
        List<Characters> charactersList = getCharListQuery.getResultList();
        List<String> namesOfCharsList = new ArrayList();
        for(Characters currentChars : charactersList)
        {
            namesOfCharsList.add(currentChars.getName());
        }
        return namesOfCharsList.toArray(new String[namesOfCharsList.size()]);
    }
    
    private void getCharStats(String character)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        //decrease character slots by 1; if slots too low return error
        TypedQuery<Characters> getCharListQuery = em.createNamedQuery("Characters.findByName", Characters.class);
        getCharListQuery.setParameter("name", character);
        List<Characters> charactersList = getCharListQuery.getResultList();
        List<String> namesOfCharsList = new ArrayList();
        for(Characters currentChars : charactersList)
        {
            showMessageDialog(frame, "Informatie van: " + currentChars.getName() +
            ". Level: " + currentChars.getLevel() + ". Klasse: " + currentChars.getClass1()
            + ". Ras: " + currentChars.getRace());
        }
    }
    
    private void AddSlots()    
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        for(Users currentUsers : usersList)
        {
            //check input and balance
            if(Integer.parseInt(slotText.getText()) <= currentUsers.getBalance())
            {
                currentUsers.setCharacterSlots(currentUsers.getCharacterSlots() + Integer.parseInt(slotText.getText()));
                currentUsers.setBalance(currentUsers.getBalance() - Integer.parseInt(slotText.getText()));
                showMessageDialog(frame, "Slots toegevoegd!");
                em.persist(currentUsers);
                em.getTransaction().commit();
            }
            else
            {
                //else display error
                showMessageDialog(frame, "U heeft te weinig geld, of u heeft geen nummer ingevoerd.");
            }
        }
    }
    
    private void AddCash()    
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        for(Users currentUsers : usersList)
        {
            //check input and balance
            if(ibanText.getText().equals(currentUsers.getIban()) && !addCashText.getText().equals("") && !ibanText.getText().equals(nameText))
            {
                currentUsers.setBalance(currentUsers.getBalance() + Integer.parseInt(addCashText.getText()));
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                //YYYY/MM/DD HH:MM:SS
                currentUsers.setLastPayment(date);
                showMessageDialog(frame, "Geld toegevoegd!");
                em.persist(currentUsers);
                em.getTransaction().commit();
            }
            else
            {
                //else display error
                showMessageDialog(frame, "U heeft geen nummer ingevoerd.");
            }
        }
    }
    
    private String getLastPayment()    
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        for(Users currentUsers : usersList)
        {
            return currentUsers.getLastPayment().toString();
        }
        return "COuld not determine last payment.";
    }
    
    private void connectToServer()    
    {
        //note: I got lazy and decided to only create one server, thus the values are had-coded.
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TypedQuery<Servers> getCurrentServerQuery = em.createNamedQuery("Servers.findByName", Servers.class);
        getCurrentServerQuery.setParameter("name", "server1");
        List<Servers> serverlist  = getCurrentServerQuery.getResultList();
        for(Servers currentServers : serverlist)
        {      
            currentServers.setConnectedUsers(currentServers.getConnectedUsers() + 1);
            showMessageDialog(frame, "Connected!");
            connectedLabel.setText("You are connected!");
            em.persist(currentServers);
            em.getTransaction().commit();    
        }
    }
    
    private void disconnectToServer()    
    {
        //note: I got lazy and decided to only create one server, thus the values are had-coded.
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TypedQuery<Servers> getCurrentServerQuery = em.createNamedQuery("Servers.findByName", Servers.class);
        getCurrentServerQuery.setParameter("name", "server1");
        
        
        List<Servers> serverlist  = getCurrentServerQuery.getResultList();
        for(Servers currentServers : serverlist)
        {
                showMessageDialog(frame, currentServers.getConnectedUsers());
                if(connectedLabel.getText().equals("You are connected!"))
                {
                    currentServers.setConnectedUsers(currentServers.getConnectedUsers() - 1);
                    showMessageDialog(frame, "Disconnected!");
                    connectedLabel.setText("You are not connected!");
                    em.persist(currentServers);
                    em.getTransaction().commit();
                }
                else
                {
                    showMessageDialog(frame, "You are not connected at this moment, disconnect not possible.");
                }
        }
    }
    
    private String getAmountOfSlots()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        String slots;
        for(Users currentUsers : usersList)
        {
            return slots =  currentUsers.getCharacterSlots().toString();
        }
        return "Slots amount unknown";
    }
    
    private String getCurrentFunds()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        List<Users> usersList = getCurrentUserQuery.getResultList();
        String money;
        for(Users currentUsers : usersList)
        {
            return money =  currentUsers.getBalance().toString();
        }
        return "Balance unknown";
    }
    
    /*
    private void getCharList()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Users> getCurrentUserQuery = em.createNamedQuery("Users.findByUserName", Users.class);
        getCurrentUserQuery.setParameter("userName", currentUser);
        //getCurrentUserQuery.
        List<Users> usersList = getCurrentUserQuery.getResultList();
        for(Users currentUsers : usersList)
        {
            //cast collection to list
            List<Characters> chars = (List)currentUsers.getCharactersCollection();
            
        }
    }
    */
    
    public CharacterManagementGUI(String user)
    {
        currentUser = user; 
        initGUI();   
    }

}