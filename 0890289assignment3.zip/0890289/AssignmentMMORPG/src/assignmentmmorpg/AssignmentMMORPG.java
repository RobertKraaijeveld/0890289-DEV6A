/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentmmorpg;

import assignmentmmorpg.DBStuff.GetDBAverages;
import java.awt.BorderLayout;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Robert
 */
public class AssignmentMMORPG {
    
    
    public static void main(String[] args) 
    {
        {
            //LoginGUI startGUI = new LoginGUI();
            DBStuff db = new DBStuff();
            /*
            for(int i = 0; i < 1000; i++)
            {
                GetDBAverages.FillCharactersTable();
            }
            System.out.println("Characters filled");
            for (int i = 0; i < 1000; i++)
            {
                GetDBAverages.FillUsersTable();
            }
            System.out.println("Users filled"); 
             */
            GetDBAverages.GetAverages();
        }
    }
    
    public static void persist(Object object)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssigmentMMORPGPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try 
        {
            em.persist(object);
            em.getTransaction().commit();
        } 
        catch (Exception e)
        {
            e.printStackTrace();
            em.getTransaction().rollback();
        } 
        finally 
        {
            em.close();
        }
    }
    
}
