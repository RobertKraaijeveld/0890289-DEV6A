/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentmmorpg;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Robert
 */
public class UserManagementGUI 
{
    public void initGUI()
    {
	JFrame frame = new JFrame("User Management");
	frame.setSize(500, 500);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	JPanel panel = new JPanel();
	frame.add(panel);
	placeComponents(panel);

	frame.setVisible(true);	
    }

    private static void placeComponents(JPanel panel)
    {
        //ADD: Userinformation labels
        panel.setLayout(null);

        //money
        
        JLabel moneyTitleLabel = new JLabel("Add Money");
	moneyTitleLabel.setBounds(10, 10, 80, 25);
        panel.add(moneyTitleLabel);
        
	JLabel moneyLabel = new JLabel("Enter amount");
	moneyLabel.setBounds(10, 20, 80, 25);
        panel.add(moneyLabel);

	JTextField moneyText = new JTextField(20);
	moneyText.setBounds(10, 20, 80, 25);
	panel.add(moneyText);

	JButton confirmMoneyButton = new JButton("Confirm");
	confirmMoneyButton.setBounds(10, 40, 80, 25);
	panel.add(confirmMoneyButton); 
        
        //subscription
        
        JLabel subscriptionLabel = new JLabel("Renew your subscription");
	subscriptionLabel.setBounds(20, 10, 80, 25);
	panel.add(subscriptionLabel);
                
        JLabel subscription1Label = new JLabel("1 month");
	subscription1Label.setBounds(20, 15, 80, 25);
	panel.add(subscription1Label);

        JCheckBox subscriptionOneMonth = new JCheckBox();
        subscriptionOneMonth.setBounds(20, 15, 10, 10);
        panel.add(subscriptionOneMonth);
                        
        JLabel subscription2Label = new JLabel("2 months");
        subscription2Label.setBounds(20, 25, 80, 25);
	panel.add(subscription2Label);

        JCheckBox subscriptionTwoMonths = new JCheckBox();
        subscriptionTwoMonths.setBounds(20, 25, 10, 10);
        panel.add(subscriptionTwoMonths);
                        
        JLabel subscription4Label = new JLabel("4 months");
	subscription4Label.setBounds(20, 35, 80, 25);
	panel.add(subscription4Label);

        JCheckBox subscriptionFourMonths = new JCheckBox();
        subscriptionFourMonths.setBounds(20, 35, 80, 25);
                        
        JLabel subscriptionYLabel = new JLabel("12 months");
	subscriptionYLabel.setBounds(20, 45, 80, 25);
	panel.add(subscriptionYLabel);

        JCheckBox subscriptionY = new JCheckBox();
        subscriptionY.setBounds(20, 45, 80, 25);
        panel.add(subscriptionY);

	JButton confirmSubscriptionButton = new JButton("Confirm");
	confirmSubscriptionButton.setBounds(20, 80, 80, 25);
	panel.add(confirmSubscriptionButton);
        
        //character slots
        
        JLabel slotsLabel = new JLabel("Enter amount");
	slotsLabel.setBounds(30, 10, 80, 25);
	panel.add(slotsLabel);

	JTextField slotsText = new JTextField(20);
	slotsText.setBounds(30, 10, 160, 25);
	panel.add(slotsText);

	JButton slotsButton = new JButton("Confirm");
	slotsButton.setBounds(30, 80, 80, 25);
	panel.add(slotsButton);
        
        //back to login
        
        JButton backButton = new JButton("Back to loginscreen");
	backButton.setBounds(50, 80, 80, 25);
	panel.add(backButton);
        
    }
        
    public UserManagementGUI()
    {
           initGUI();   
    }
    
}
