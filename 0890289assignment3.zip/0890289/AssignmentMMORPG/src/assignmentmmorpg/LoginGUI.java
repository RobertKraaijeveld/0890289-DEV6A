/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assignmentmmorpg;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginGUI {
        //global vars (dirty yet needed, kind of like horror movies)
        JFrame frame;
        String username;
        
        JTextField userText;
        JTextField passwordText;
        JButton loginButton;
        JTextField userRegisterText;
        
        JTextField passwordRegisterText;
        JTextField ibanRegisterText;
        JButton registerButton;
        JTextField fnameRegisterText;
        JTextField lnameRegisterText;
        
        
	public void initGUI()
        {
		frame = new JFrame("Welcome to Warhammer!");
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.add(panel);
		placeComponents(panel);

		frame.setVisible(true);
	}
        
        
        
	private void placeComponents(JPanel panel)
        {
                //ADD: Buttonlisteners
		panel.setLayout(null);
                
                //logging in
                
		JLabel userLabel = new JLabel("User");
		userLabel.setBounds(10, 10, 80, 25);
		panel.add(userLabel);


                userText = new JTextField(20);
		userText.setBounds(100, 10, 160, 25);
		panel.add(userText);

		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setBounds(10, 40, 80, 25);
		panel.add(passwordLabel);

		passwordText = new JTextField(20);
		passwordText.setBounds(100, 40, 160, 25);
		panel.add(passwordText);

		loginButton = new JButton("login");
		loginButton.setBounds(10, 80, 80, 25);
		panel.add(loginButton);
                loginButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    Users T_users = new Users();
                    LoginUser(T_users);
                }
                });
                
                //register account
                
                JLabel registerTitleLabel = new JLabel("Sign up!");
		registerTitleLabel.setBounds(10, 110, 80, 25);
		panel.add(registerTitleLabel);
                
                JLabel userRegisterLabel = new JLabel("Username");
		userRegisterLabel.setBounds(10, 130, 80, 25);
		panel.add(userRegisterLabel);

		userRegisterText = new JTextField(20);
		userRegisterText.setBounds(100, 130, 160, 25);
		panel.add(userRegisterText);

		JLabel passwordRegisterLabel = new JLabel("Password");
		passwordRegisterLabel.setBounds(10, 170, 80, 25);
		panel.add(passwordRegisterLabel);

                passwordRegisterText = new JTextField(20);
		passwordRegisterText.setBounds(100, 170, 160, 25);
		panel.add(passwordRegisterText);
                
                JLabel ibanRegisterLabel = new JLabel("IBAN");
		ibanRegisterLabel.setBounds(10, 210, 80, 25);
		panel.add(ibanRegisterLabel);

		ibanRegisterText = new JTextField(20);
		ibanRegisterText.setBounds(100, 210, 160, 25);
		panel.add(ibanRegisterText);

                JLabel nameRegisterLabel = new JLabel("Voornaam:");
		nameRegisterLabel.setBounds(10, 260, 80, 25);
		panel.add(nameRegisterLabel);

		fnameRegisterText = new JTextField(20);
		fnameRegisterText.setBounds(100, 260, 160, 25);
		panel.add(fnameRegisterText);
                
                JLabel lnameRegisterLabel = new JLabel("Achternaam:");
		lnameRegisterLabel.setBounds(10, 290, 80, 25);
		panel.add(lnameRegisterLabel);
                
                lnameRegisterText = new JTextField(20);
		lnameRegisterText.setBounds(100, 290, 160, 25);
		panel.add(lnameRegisterText);
                
		registerButton = new JButton("Register me!");
		registerButton.setBounds(10, 320, 80, 25);
		panel.add(registerButton);
                registerButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e)
                {
                    //Execute when button is pressed
                    Users T_users = new Users();
                    RegistrateUser(T_users);
                }
                });
                
                
	}
        
        private void RegistrateUser(Object object)
        {
                EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
                EntityManager em = emf.createEntityManager();
                //check fields
                if(!userRegisterText.getText().equals("") 
                && !passwordRegisterText.getText().equals("")
                && !ibanRegisterText.getText().equals("") 
                && !fnameRegisterText.getText().equals("")
                && !lnameRegisterText.getText().equals(""))
                {
                    
                    em.getTransaction().begin();
                    //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
                    TypedQuery<Users> checkUserNameAvailabilityQuery = em.createNamedQuery("Users.findByUserName", Users.class);
                    checkUserNameAvailabilityQuery.setParameter("userName", userRegisterText.getText());
                    List<Users> knownUsers = checkUserNameAvailabilityQuery.getResultList();
                    //check if username taken
                    
                    for(Users user : knownUsers)
                    {
                        username = userRegisterText.getText();  
                    }
                    //deze check gaat fout
                        if(!userRegisterText.getText().equals(username))
                        {    
                            InsertUser();
                            showMessageDialog(frame, "method started");
                        }
                        else
                        {
                            showMessageDialog(frame, "Deze gebruikersnaam is al bezet!");
                        }      
                }
    
            else
            {
                //fields incorrect
                showMessageDialog(frame, "U heeft 1 of meerdere velden niet ingevuld.");
            }  
        }
        
        private void InsertUser()
        {
                    EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
                    EntityManager em = emf.createEntityManager();
                    em.getTransaction().begin();
                    //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
                    Users userEntity = new Users();
                    //create new persistence object and push changes
                    userEntity.setUserName(userRegisterText.getText());
                    userEntity.setPassword(passwordRegisterText.getText());
                    userEntity.setIban(ibanRegisterText.getText());
                    userEntity.setFirstName(fnameRegisterText.getText());
                    userEntity.setLastName(lnameRegisterText.getText());
                    userEntity.setBalance(10);
                    userEntity.setCharacterSlots(3);
                    showMessageDialog(frame, "Gefeliciteerd, u bent geregistreerd!");
                    em.persist(userEntity);
                    em.getTransaction().commit();
        }
        
        private void LoginUser(Object object)
        {
                EntityManagerFactory emf = Persistence.createEntityManagerFactory("AssignmentMMORPGPU");
                EntityManager em = emf.createEntityManager();
                
                //check fields
                if
                (userText.getText() != null || passwordText.getText() != null)
                {
                    em.getTransaction().begin();
                    //note to self: Query van type <classdiejewilt>, daarna loop je door t resultaat heen en kan je bij de velden
                    TypedQuery<Users> checkUserNameQuery = em.createNamedQuery("Users.findByUserName", Users.class);
                    checkUserNameQuery.setParameter("userName", userText.getText());
                    List<Users> knownUsers = checkUserNameQuery.getResultList();
                    
                    //check if username taken
                    //check username
                    for(Users usernames : knownUsers)
                    {
                        if(userText.getText().equals(usernames.getUserName()))
                        {
                            //matched username, then check password
                                if(passwordText.getText().equals(usernames.getPassword()))
                                {
                                    //acess granted: goto user management
                                    showMessageDialog(frame, "Welkom, " + usernames.getUserName() + "!");
                                    CharacterManagementGUI charGUI = new CharacterManagementGUI(usernames.getUserName());
                                }
                                else
                                {
                                    //failure
                                    showMessageDialog(frame, "Uw wachtwoord is incorrect.");
                                }
                        }
                        else
                        {
                            //failure
                            showMessageDialog(frame, "Deze gebruikersnaam is onbekend.");
                        }
                    }
                }
                else
                {
                    //fiels empty
                    showMessageDialog(frame, "U heeft 1 of meerdere velden niet ingevuld.");
                }
        }
        
        
        public LoginGUI()
        {
           initGUI();   
        }
}

